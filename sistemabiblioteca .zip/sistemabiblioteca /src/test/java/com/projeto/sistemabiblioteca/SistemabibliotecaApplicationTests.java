package com.projeto.sistemabiblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemabibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
