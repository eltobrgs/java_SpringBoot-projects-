package com.projeto.sistemabiblioteca.repositories;

import com.projeto.sistemabiblioteca.entities.Emprestimo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {
}
