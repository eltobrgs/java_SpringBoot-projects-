package com.projeto.sistemabiblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemabibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemabibliotecaApplication.class, args);
	}

}
